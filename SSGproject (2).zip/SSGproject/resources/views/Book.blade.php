<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
</head>
<body>

<div>
              <div>
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                      <a class="navbar-brand" href="#">SSG RESORT WATAPAMPAM</a>
                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                      </button>

                      <div class="collapse navbar-collapse" id="navbarNav">
                          <ul class="navbar-nav">
                            <li class="nav-item active" >
                              <a class="nav-link" href="http://127.0.0.1:8000">HOME <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="http://127.0.0.1:8000/About">ABOUT US</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">CONTACT US</a>
                            </li>
                          </ul>
                        </div>
                        <form class="form-inline my-2 my-lg-0">
                          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                        </form>
                      </div>
                    </nav>
              </div>

              <center>
                <div class="container" style="margin-top: 100px; font-size: 20px;" >
                   <div class="col mb-4">
                      <div class="card">
                          <div class="card-body">
                              <h5 class="card-title">RESERVAION SUMMARY</h5>
                               <p class="card-text" style="margin-top:50px;">Full Name: Cyrex Joshua M. Cuizon</p>
                               <p>Address: Fatima Village</p>
                               <p>Adults: 5</p>
                               <p>Children: 15</p>
                          </div>
                        </div>
                    </div>
                </div>
              </center> 
        </div>

          <center>
             <div id="foot" style="font-size:10px; margin-top: 350px;">
                <h6>@COPYRIGHT 2022 All Reserve | SSG RESORT WATAMPAM</h6>
             </div>
          </center>
            
</div>
    
</body>
</html>